package ij.measure;

public interface Measurements {
	public static final int AREA=1,MEAN=2,STD_DEV=4,MODE=8,MIN_MAX=16,
		CENTROID=32,CENTER_OF_MASS=64,PERIMETER=128, LIMIT = 256, RECT=512,
		LABELS=1024,ELLIPSE=2048,INVERT_Y=4096,CIRCULARITY=8192,FERET=16384,
		INTEGRATED_DENSITY=0x8000,
		MEDIAN=0x10000, SKEWNESS=0x20000, KURTOSIS=0x40000, AREA_FRACTION=0x80000, 
		SLICE=0x100000;
		
	/** Maximum number of calibration standard (20) */
	public static final int MAX_STANDARDS = 20;

}
